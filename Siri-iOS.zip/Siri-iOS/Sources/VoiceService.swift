import Foundation
import AVFoundation
import Speech

final class VoiceService: NSObject, AVSpeechSynthesizerDelegate {
    var micLevel: Double = 0
    private(set) var isListening = false
    var onFinalText: ((String) -> Void)?
    var onNoSpeech: (() -> Void)?
    var onSpeakEnd: (() -> Void)?
    var onWord: (() -> Void)?
    var onError: ((String) -> Void)?

    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "pt-BR"))
    private let engine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private let synth = AVSpeechSynthesizer()
    private var lastText = ""
    private var silenceTimer: Timer?

    override init() {
        super.init()
        synth.delegate = self
    }

    // ---------- permissões (o iOS pergunta; nada é usado sem autorização) ----------
    func requestPermissions(_ done: @escaping (Bool) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in
            AVAudioApplication.requestRecordPermission { granted in
                DispatchQueue.main.async { done(status == .authorized && granted) }
            }
        }
    }

    // ---------- ouvir ----------
    func startListening() {
        stopSpeaking()
        guard !isListening else { return }
        guard let recognizer = recognizer, recognizer.isAvailable else {
            onError?("O reconhecimento de voz em português não está disponível agora. Verifique a internet e tente de novo.")
            return
        }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .default, options: [.defaultToSpeaker])
            try session.setActive(true)
            let req = SFSpeechAudioBufferRecognitionRequest()
            req.shouldReportPartialResults = true
            request = req
            lastText = ""
            let input = engine.inputNode
            let format = input.outputFormat(forBus: 0)
            input.removeTap(onBus: 0)
            input.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak self] buf, _ in
                req.append(buf)
                let n = Int(buf.frameLength)
                guard n > 0, let ch = buf.floatChannelData?[0] else { return }
                var sum: Float = 0
                for i in 0..<n { sum += ch[i] * ch[i] }
                let lvl = min(1.0, Double(sqrt(sum / Float(n))) * 8)
                DispatchQueue.main.async { self?.micLevel = lvl }
            }
            engine.prepare()
            try engine.start()
            isListening = true
            task = recognizer.recognitionTask(with: req) { [weak self] result, error in
                DispatchQueue.main.async {
                    guard let self = self, self.isListening else { return }
                    if let r = result {
                        self.lastText = r.bestTranscription.formattedString
                        self.armTimer(1.4)
                        if r.isFinal { self.finish() }
                    }
                    if error != nil { self.finish() }
                }
            }
            armTimer(7.0)
        } catch {
            cleanup()
            onError?("Não foi possível usar o microfone: \(error.localizedDescription)")
        }
    }

    private func armTimer(_ s: TimeInterval) {
        silenceTimer?.invalidate()
        silenceTimer = Timer.scheduledTimer(withTimeInterval: s, repeats: false) { [weak self] _ in self?.finish() }
    }

    private func cleanup() {
        silenceTimer?.invalidate()
        if engine.isRunning { engine.stop() }
        engine.inputNode.removeTap(onBus: 0)
        request?.endAudio()
        task?.cancel()
        request = nil; task = nil
        isListening = false
        micLevel = 0
    }

    private func finish() {
        guard isListening else { return }
        cleanup()
        let text = lastText.trimmed
        if text.isEmpty { onNoSpeech?() } else { onFinalText?(text) }
    }

    func stopListening() { finish() }

    // ---------- falar ----------
    @discardableResult
    func speak(_ text: String, volume: Double) -> Bool {
        guard let voice = AVSpeechSynthesisVoice(language: "pt-BR") else {
            onError?("Nenhuma voz em português (Brasil) encontrada. Baixe uma em Ajustes > Acessibilidade > Conteúdo Falado > Vozes.")
            return false
        }
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playback, mode: .spokenAudio, options: [])
        try? s.setActive(true)
        let clean = text.replacingOccurrences(of: "*", with: "").replacingOccurrences(of: "#", with: "").replacingOccurrences(of: "`", with: "")
        let u = AVSpeechUtterance(string: clean)
        u.voice = voice
        u.volume = Float(max(0, min(1, volume)))
        synth.speak(u)
        return true
    }

    func stopSpeaking() {
        if synth.isSpeaking { synth.stopSpeaking(at: .immediate) }
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        DispatchQueue.main.async { self.onWord?() }
    }
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        DispatchQueue.main.async { self.onSpeakEnd?() }
    }
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        DispatchQueue.main.async { self.onSpeakEnd?() }
    }
}
