import Foundation

struct Provider {
    let id: String, name: String, url: String, model: String, kind: String
}

enum Providers {
    // Nomes de modelo mudam com o tempo: o campo "Modelo" nos Ajustes é editável.
    static let all: [Provider] = [
        Provider(id: "gemini", name: "Google Gemini (tem plano gratuito)", url: "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", model: "gemini-2.5-flash", kind: "openai"),
        Provider(id: "anthropic", name: "Anthropic Claude", url: "https://api.anthropic.com/v1/messages", model: "claude-haiku-5-5", kind: "anthropic"),
        Provider(id: "openai", name: "OpenAI", url: "https://api.openai.com/v1/chat/completions", model: "gpt-4o-mini", kind: "openai"),
        Provider(id: "groq", name: "Groq", url: "https://api.groq.com/openai/v1/chat/completions", model: "llama-3.3-70b-versatile", kind: "openai"),
        Provider(id: "openrouter", name: "OpenRouter", url: "https://openrouter.ai/api/v1/chat/completions", model: "openrouter/auto", kind: "openai"),
        Provider(id: "custom", name: "Personalizado (compatível com OpenAI)", url: "", model: "", kind: "openai")
    ]
    static func get(_ id: String) -> Provider { all.first { $0.id == id } ?? all[0] }
}

struct AIError: LocalizedError {
    let message: String
    init(_ m: String) { message = m }
    var errorDescription: String? { message }
}

enum AIClient {
    static let systemPrompt = "Você é a Siri, uma assistente de voz e chat. Responda sempre em português do Brasil, de forma natural, clara e concisa, adequada para ser falada em voz alta. Não use markdown, listas com símbolos nem emojis."

    static func ask(history: [ChatMessage], providerId: String, model: String, baseURL: String, apiKey: String) async throws -> String {
        let key = apiKey.trimmed
        guard !key.isEmpty else { throw AIError("Nenhuma chave de API configurada. Abra os Ajustes (engrenagem), escolha o provedor e cole sua chave.") }
        let p = Providers.get(providerId)
        let urlStr = p.id == "custom" ? baseURL.trimmed : p.url
        let mdl = model.trimmed.isEmpty ? p.model : model.trimmed
        guard !urlStr.isEmpty, let url = URL(string: urlStr) else { throw AIError("Informe a URL da API nos Ajustes (provedor personalizado).") }
        guard !mdl.isEmpty else { throw AIError("Informe o nome do modelo nos Ajustes.") }

        var recent = Array(history.suffix(20))
        while let f = recent.first, f.role != "user" { recent.removeFirst() }
        let msgs: [[String: String]] = recent.map { ["role": $0.role, "content": $0.text] }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 60
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let body: [String: Any]
        if p.kind == "anthropic" {
            req.setValue(key, forHTTPHeaderField: "x-api-key")
            req.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
            body = ["model": mdl, "max_tokens": 1024, "system": systemPrompt, "messages": msgs]
        } else {
            req.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
            let all: [[String: String]] = [["role": "system", "content": systemPrompt]] + msgs
            body = ["model": mdl, "messages": all]
        }
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, status) = try await fetch(req)
        if !(200..<300).contains(status) { throw AIError(describe(status, data)) }
        return try parse(data, kind: p.kind)
    }

    private static func fetch(_ req: URLRequest) async throws -> (Data, Int) {
        do {
            let (data, resp) = try await URLSession.shared.data(for: req)
            return (data, (resp as? HTTPURLResponse)?.statusCode ?? 0)
        } catch let e as URLError {
            if e.code == .timedOut { throw AIError("A IA demorou demais para responder (tempo esgotado). Verifique a internet e tente de novo.") }
            throw AIError("Sem conexão com o provedor de IA: \(e.localizedDescription)")
        }
    }

    private static func describe(_ code: Int, _ data: Data) -> String {
        var detail = ""
        if let o = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let e = o["error"] as? [String: Any], let m = e["message"] as? String { detail = m }
        var head: String
        switch code {
        case 401, 403: head = "A chave de API foi recusada (erro \(code)). Confira a chave e o provedor."
        case 404: head = "Modelo ou endereço não encontrado (erro 404). Confira o nome do modelo."
        case 429: head = "Limite de uso ou de créditos atingido (erro 429). Aguarde um pouco ou verifique seu plano."
        case 500...: head = "O provedor está com problemas agora (erro \(code)). Tente de novo em instantes."
        default: head = "O provedor recusou o pedido (erro \(code))."
        }
        if !detail.isEmpty { head += "\nDetalhe: " + String(detail.prefix(220)) }
        return head
    }

    private static func parse(_ data: Data, kind: String) throws -> String {
        if let o = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            if kind == "anthropic" {
                if let parts = o["content"] as? [[String: Any]] {
                    let t = parts.compactMap { $0["text"] as? String }.joined().trimmed
                    if !t.isEmpty { return t }
                }
            } else if let ch = o["choices"] as? [[String: Any]], let m = ch.first?["message"] as? [String: Any],
                      let t = (m["content"] as? String)?.trimmed, !t.isEmpty {
                return t
            }
        }
        throw AIError("O provedor respondeu vazio ou em formato inesperado. Confira o modelo escolhido.")
    }
}
