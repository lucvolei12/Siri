import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var vm: AssistantViewModel
    @Environment(\.dismiss) private var dismiss
    @AppStorage("provider") private var provider = "gemini"
    @AppStorage("model") private var model = ""
    @AppStorage("baseURL") private var baseURL = ""
    @AppStorage("speak") private var speak = true
    @AppStorage("volume") private var volume = 0.9
    @AppStorage("theme") private var theme = "violeta"
    @State private var key = ""
    @State private var hasKey = !Keychain.get(account: "apikey").isEmpty
    @State private var testResult = ""
    @State private var testing = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Inteligência artificial") {
                    Picker("Provedor", selection: $provider) {
                        ForEach(Providers.all, id: \.id) { Text($0.name).tag($0.id) }
                    }
                    TextField("Modelo (vazio = padrão: \(Providers.get(provider).model))", text: $model)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                    if provider == "custom" {
                        TextField("URL da API", text: $baseURL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    SecureField(hasKey ? "Chave salva — digite para trocar" : "Chave de API", text: $key)
                    Button("Salvar chave") {
                        Keychain.set(key.trimmed, account: "apikey")
                        hasKey = !key.trimmed.isEmpty || hasKey
                        key = ""
                    }.disabled(key.trimmed.isEmpty)
                    Text("A chave fica no Chaveiro do iPhone, criptografada pelo sistema. Nunca vai no código.")
                        .font(.footnote).foregroundColor(.secondary)
                    Button(testing ? "Testando…" : "Testar conexão com a IA") { test() }.disabled(testing)
                    if !testResult.isEmpty { Text(testResult).font(.footnote) }
                }
                Section("Voz") {
                    Toggle("Falar as respostas", isOn: $speak)
                    VStack(alignment: .leading) {
                        Text("Volume da voz")
                        Slider(value: $volume, in: 0...1)
                    }
                }
                Section("Aparência") {
                    Picker("Tema", selection: $theme) {
                        Text("Violeta").tag("violeta")
                        Text("Escuro neutro").tag("escuro")
                    }
                }
                Section {
                    Button("Apagar histórico de conversas", role: .destructive) { vm.clearHistory() }
                }
            }
            .navigationTitle("Ajustes")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Ok") { dismiss() } } }
        }
    }

    private func test() {
        testing = true
        testResult = ""
        let typed = key.trimmed
        let k = typed.isEmpty ? Keychain.get(account: "apikey") : typed
        Task {
            do {
                let r = try await AIClient.ask(history: [ChatMessage(role: "user", text: "Responda apenas: conexão ok.")],
                                               providerId: provider, model: model, baseURL: baseURL, apiKey: k)
                testResult = "✔ Resposta real da IA: " + r
            } catch {
                testResult = "✘ " + error.localizedDescription
            }
            testing = false
        }
    }
}
