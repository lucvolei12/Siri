import SwiftUI

@main
struct SiriApp: App {
    @StateObject private var vm = AssistantViewModel()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(vm)
                .preferredColorScheme(.dark)
        }
    }
}
