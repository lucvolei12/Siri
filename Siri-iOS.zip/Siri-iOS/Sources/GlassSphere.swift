import SwiftUI
import UIKit

enum Mood { case idle, listening, thinking, speaking }

extension Color {
    func mixed(with other: Color, _ k: Double) -> Color {
        let a = UIColor(self), b = UIColor(other)
        var ar: CGFloat = 0, ag: CGFloat = 0, ab: CGFloat = 0, aa: CGFloat = 0
        var br: CGFloat = 0, bg: CGFloat = 0, bb: CGFloat = 0, ba: CGFloat = 0
        a.getRed(&ar, green: &ag, blue: &ab, alpha: &aa)
        b.getRed(&br, green: &bg, blue: &bb, alpha: &ba)
        let kk = CGFloat(k)
        return Color(red: Double(ar + (br - ar) * kk), green: Double(ag + (bg - ag) * kk), blue: Double(ab + (bb - ab) * kk))
    }
}

// Esfera de vidro líquido feita só com gradientes do SwiftUI (sem imagens).
struct GlassSphereView: View {
    let mood: Mood
    let level: Double
    let violet: Bool
    var size: CGFloat = 240

    private var tint: Color {
        if violet {
            switch mood {
            case .listening: return Color(red: 0.85, green: 0.27, blue: 0.94)
            case .thinking: return Color(red: 0.39, green: 0.40, blue: 0.95)
            case .speaking: return Color(red: 0.65, green: 0.55, blue: 0.98)
            case .idle: return Color(red: 0.55, green: 0.36, blue: 0.96)
            }
        }
        switch mood {
        case .listening: return Color(red: 0.31, green: 0.76, blue: 0.97)
        case .thinking: return Color(red: 1.0, green: 0.72, blue: 0.30)
        case .speaking: return Color(red: 0.81, green: 0.88, blue: 1.0)
        case .idle: return Color(red: 0.62, green: 0.70, blue: 0.85)
        }
    }

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { tl in
            SphereLayers(t: tl.date.timeIntervalSinceReferenceDate, mood: mood, level: level, tint: tint, size: size)
        }
        .frame(width: size, height: size)
        .animation(.easeInOut(duration: 0.5), value: mood)
    }
}

private struct SphereLayers: View {
    let t: Double
    let mood: Mood
    let level: Double
    let tint: Color
    let size: CGFloat

    private var k: CGFloat { size / 200 }
    private var D: CGFloat { 140 * k }

    var body: some View {
        let breathe = 1 + 0.018 * sin(t * 1.7)
        let pulse = (mood == .listening || mood == .speaking) ? level * 0.09 : 0
        ZStack {
            glow
            ZStack {
                bodyFill
                bottomGlow
                streak
                specular
            }
            .frame(width: D, height: D)
            .clipShape(Circle())
            rim
        }
        .frame(width: size, height: size)
        .scaleEffect(CGFloat(breathe + pulse))
    }

    private var glow: some View {
        Circle()
            .fill(RadialGradient(gradient: Gradient(stops: [
                .init(color: tint.opacity(0.25), location: 0),
                .init(color: tint.opacity(0.25 + 0.38 * level), location: 0.68),
                .init(color: tint.opacity(0), location: 1)
            ]), center: .center, startRadius: 0, endRadius: size / 2))
            .frame(width: size, height: size)
    }

    private var bodyFill: some View {
        Circle()
            .fill(RadialGradient(gradient: Gradient(stops: [
                .init(color: tint.mixed(with: .white, 0.55).opacity(0.95), location: 0),
                .init(color: tint.opacity(0.63), location: 0.42),
                .init(color: Color(red: 0.05, green: 0.05, blue: 0.09).opacity(0.94), location: 0.78),
                .init(color: Color(red: 0.02, green: 0.02, blue: 0.04), location: 1)
            ]), center: UnitPoint(x: 0.5, y: 0.92), startRadius: 0, endRadius: D * 0.95))
    }

    private var bottomGlow: some View {
        Circle()
            .fill(RadialGradient(colors: [Color.white.opacity(0.88 * (0.65 + 0.35 * level)), Color.white.opacity(0)],
                                 center: .center, startRadius: 0, endRadius: 65 * k))
            .frame(width: 130 * k, height: 130 * k)
            .scaleEffect(x: 1, y: 0.54)
            .offset(y: 53 * k)
    }

    private var rainbow: LinearGradient {
        let cyan = Color(red: 0, green: 0.72, blue: 1)
        let yellow = Color(red: 1, green: 0.88, blue: 0.51)
        let orange = Color(red: 1, green: 0.44, blue: 0.26)
        let pink = Color(red: 0.88, green: 0.25, blue: 0.98)
        return LinearGradient(stops: [
            .init(color: cyan.opacity(0), location: 0),
            .init(color: cyan.opacity(0.88), location: 0.16),
            .init(color: Color.white, location: 0.40),
            .init(color: yellow.opacity(0.94), location: 0.56),
            .init(color: orange.opacity(0.94), location: 0.72),
            .init(color: pink.opacity(0.82), location: 0.88),
            .init(color: pink.opacity(0), location: 1)
        ], startPoint: .leading, endPoint: .trailing)
    }

    private var streak: some View {
        let thinking = mood == .thinking
        let dx: CGFloat = thinking ? 0 : CGFloat(sin(t * 0.9) * 16) * k
        let dy: CGFloat = thinking ? 30 * k : CGFloat(24 - level * 16 + sin(t * 1.3) * 3) * k
        let ang: Double = thinking ? (t * 150).truncatingRemainder(dividingBy: 360) : -7 + sin(t * 0.7) * 5
        let op: Double = mood == .idle ? 0.7 : min(1, 0.85 + 0.15 * level)
        return ZStack {
            ZStack {
                Ellipse().fill(rainbow).frame(width: 150 * k, height: 14 * k)
                Ellipse()
                    .fill(RadialGradient(colors: [Color.white, Color.white.opacity(0)], center: .center, startRadius: 0, endRadius: 60 * k))
                    .frame(width: 120 * k, height: 9 * k)
            }
            .offset(x: dx, y: dy)
        }
        .frame(width: D, height: D)
        .rotationEffect(.degrees(ang))
        .opacity(op)
    }

    private var specular: some View {
        Ellipse()
            .fill(RadialGradient(colors: [Color.white.opacity(0.56), Color.white.opacity(0)], center: .center, startRadius: 0, endRadius: 23 * k))
            .frame(width: 46 * k, height: 22 * k)
            .rotationEffect(.degrees(-32))
            .offset(x: -29 * k, y: -45 * k)
    }

    private var rim: some View {
        ZStack {
            Circle().strokeBorder(LinearGradient(colors: [Color.white.opacity(0.94), Color.white.opacity(0.06), Color.white.opacity(0.06), Color.white.opacity(0.75)],
                                                 startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1.6 * k)
            Circle().strokeBorder(LinearGradient(stops: [
                .init(color: Color.clear, location: 0),
                .init(color: Color.clear, location: 0.55),
                .init(color: tint.opacity(0.7), location: 1)
            ], startPoint: .top, endPoint: .bottom), lineWidth: 3 * k)
        }
        .frame(width: D, height: D)
    }
}
