import Foundation
import Security

struct ChatMessage: Codable, Identifiable {
    var id = UUID()
    var role: String   // user, assistant (salvos) | system, error (só na tela)
    var text: String
}

enum Prefs {
    static var provider: String { UserDefaults.standard.string(forKey: "provider") ?? "gemini" }
    static var model: String { UserDefaults.standard.string(forKey: "model") ?? "" }
    static var baseURL: String { UserDefaults.standard.string(forKey: "baseURL") ?? "" }
    static var speak: Bool { UserDefaults.standard.object(forKey: "speak") as? Bool ?? true }
    static var volume: Double { UserDefaults.standard.object(forKey: "volume") as? Double ?? 0.9 }
}

// A chave de API fica no Chaveiro do iPhone (criptografada pelo sistema), nunca no código.
enum Keychain {
    private static func query(_ account: String) -> [String: Any] {
        return [kSecClass as String: kSecClassGenericPassword,
                kSecAttrService as String: "Siri",
                kSecAttrAccount as String: account]
    }
    static func set(_ value: String, account: String) {
        SecItemDelete(query(account) as CFDictionary)
        if value.isEmpty { return }
        var q = query(account)
        q[kSecValueData as String] = Data(value.utf8)
        q[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(q as CFDictionary, nil)
    }
    static func get(account: String) -> String {
        var q = query(account)
        q[kSecReturnData as String] = true
        q[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: AnyObject?
        if SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess, let d = out as? Data {
            return String(data: d, encoding: .utf8) ?? ""
        }
        return ""
    }
}

enum Store {
    private static var url: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("history.json")
    }
    static func loadHistory() -> [ChatMessage] {
        guard let d = try? Data(contentsOf: url), let m = try? JSONDecoder().decode([ChatMessage].self, from: d) else { return [] }
        return m
    }
    static func saveHistory(_ messages: [ChatMessage]) {
        let keep = messages.filter { $0.role == "user" || $0.role == "assistant" }
        if let d = try? JSONEncoder().encode(keep) { try? d.write(to: url) }
    }
    static func clearHistory() { try? FileManager.default.removeItem(at: url) }
}

extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}
