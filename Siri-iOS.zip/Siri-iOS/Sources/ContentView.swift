import SwiftUI

struct ContentView: View {
    @EnvironmentObject var vm: AssistantViewModel
    @AppStorage("theme") private var theme = "violeta"
    @FocusState private var focused: Bool

    private var violet: Bool { theme == "violeta" }

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.03, green: 0.03, blue: 0.06),
                                    violet ? Color(red: 0.10, green: 0.06, blue: 0.18) : Color(red: 0.05, green: 0.07, blue: 0.12)],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            VStack(spacing: 0) {
                topBar
                sphereArea
                if vm.showChat { chat.transition(.move(edge: .bottom).combined(with: .opacity)) } else { Spacer(minLength: 0) }
                inputBar
            }
        }
        .animation(.spring(response: 0.45, dampingFraction: 0.85), value: vm.showChat)
        .sheet(isPresented: $vm.showSettings) { SettingsView().environmentObject(vm) }
        .onChange(of: focused) { _, f in if f { vm.showChat = true } }
    }

    private var topBar: some View {
        HStack {
            if vm.mood == .listening {
                HStack(spacing: 6) {
                    Circle().fill(Color.red).frame(width: 9, height: 9)
                    Text("Microfone ativo").font(.caption).foregroundColor(.white)
                }
                .padding(.horizontal, 10).padding(.vertical, 6)
                .background(.ultraThinMaterial, in: Capsule())
            }
            Spacer()
            glassButton("keyboard") { vm.showChat.toggle(); if vm.showChat { focused = true } else { focused = false } }
            glassButton("gearshape") { focused = false; vm.showSettings = true }
        }
        .padding(.horizontal, 16).padding(.top, 8)
    }

    private func glassButton(_ icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon).font(.system(size: 16, weight: .medium)).foregroundColor(.white)
                .frame(width: 38, height: 38)
                .background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().stroke(Color.white.opacity(0.25), lineWidth: 1))
        }
    }

    private var sphereArea: some View {
        VStack(spacing: 6) {
            GlassSphereView(mood: vm.mood, level: vm.level, violet: violet, size: vm.showChat ? 170 : 270)
                .contentShape(Circle())
                .onTapGesture { focused = false; vm.sphereTapped() }
            Text(vm.status).font(.footnote).foregroundColor(Color.white.opacity(0.75))
        }
        .frame(maxHeight: vm.showChat ? 230 : .infinity)
    }

    private var chat: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 6) {
                    ForEach(vm.messages) { m in
                        Bubble(m: m, violet: violet).id(m.id)
                    }
                }
                .padding(.horizontal, 14).padding(.vertical, 10)
            }
            .onChange(of: vm.messages.count) { _, _ in
                if let last = vm.messages.last { withAnimation { proxy.scrollTo(last.id, anchor: .bottom) } }
            }
        }
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 28, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 1))
        .padding(.horizontal, 12)
    }

    private var inputBar: some View {
        HStack(spacing: 8) {
            TextField("Pergunte à Siri", text: $vm.input)
                .focused($focused)
                .submitLabel(.send)
                .onSubmit { let t = vm.input; vm.input = ""; vm.send(t) }
                .foregroundColor(.white)
                .padding(.leading, 16)
            Button { focused = false; vm.sphereTapped() } label: {
                Image(systemName: vm.mood == .listening ? "mic.fill" : "mic")
                    .foregroundColor(.white).frame(width: 40, height: 40)
            }
        }
        .frame(height: 48)
        .background(.ultraThinMaterial, in: Capsule())
        .overlay(Capsule().stroke(Color.white.opacity(0.25), lineWidth: 1))
        .padding(.horizontal, 14).padding(.vertical, 10)
    }
}

private struct Bubble: View {
    let m: ChatMessage
    let violet: Bool
    var body: some View {
        let isUser = m.role == "user"
        let bg: Color = isUser ? (violet ? Color(red: 0.55, green: 0.36, blue: 0.96).opacity(0.6) : Color(red: 0.23, green: 0.51, blue: 0.96).opacity(0.6))
            : (m.role == "error" ? Color.red.opacity(0.5) : Color.white.opacity(m.role == "system" ? 0.12 : 0.18))
        HStack {
            if isUser { Spacer(minLength: 40) }
            Text(m.text)
                .font(.system(size: 15))
                .foregroundColor(.white)
                .padding(.horizontal, 12).padding(.vertical, 8)
                .background(bg, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            if !isUser { Spacer(minLength: 40) }
        }
    }
}
