import SwiftUI

@MainActor
final class AssistantViewModel: ObservableObject {
    @Published var messages: [ChatMessage] = []
    @Published var mood: Mood = .idle
    @Published var level: Double = 0
    @Published var status = "Toque na esfera para falar"
    @Published var input = ""
    @Published var showChat = false
    @Published var showSettings = false

    let voice = VoiceService()
    private var busy = false
    private var speakEnv = 0.0
    private var timer: Timer?

    var hasKey: Bool { !Keychain.get(account: "apikey").isEmpty }

    init() {
        messages = Store.loadHistory()
        voice.onFinalText = { [weak self] t in self?.send(t) }
        voice.onNoSpeech = { [weak self] in self?.setMood(.idle, "Não entendi. Toque e fale de novo.") }
        voice.onWord = { [weak self] in self?.speakEnv = 1.0 }
        voice.onSpeakEnd = { [weak self] in
            guard let self = self else { return }
            if self.mood == .speaking { self.setMood(.idle) }
        }
        voice.onError = { [weak self] m in
            self?.addNote("error", m)
            self?.setMood(.idle)
        }
        timer = Timer.scheduledTimer(withTimeInterval: 1.0 / 30.0, repeats: true) { [weak self] _ in
            Task { @MainActor in self?.tick() }
        }
        if !hasKey && messages.isEmpty {
            showChat = true
            addNote("system", "Para conversar de verdade, abra os Ajustes (engrenagem), escolha um provedor de IA e cole sua chave de API. Sem chave, a Siri não responde.")
        }
    }

    private func tick() {
        let t = Date().timeIntervalSinceReferenceDate
        var target = 0.0
        switch mood {
        case .listening: target = voice.micLevel
        case .speaking:
            speakEnv *= 0.9
            target = min(1, 0.25 + 0.2 * sin(t * 9) + 0.6 * speakEnv)
        case .thinking: target = 0.35 + 0.15 * sin(t * 3)
        case .idle: target = 0
        }
        let n = level + (target - level) * 0.25
        if abs(n - level) > 0.0005 { level = n }
    }

    func setMood(_ m: Mood, _ custom: String? = nil) {
        mood = m
        if let c = custom { status = c; return }
        switch m {
        case .listening: status = "Ouvindo…"
        case .thinking: status = "Pensando…"
        case .speaking: status = "Falando… toque na esfera para interromper"
        case .idle: status = "Toque na esfera para falar"
        }
    }

    func addNote(_ role: String, _ text: String) {
        messages.append(ChatMessage(role: role, text: text))
        showChat = true
    }

    func sphereTapped() {
        if mood == .listening { voice.stopListening(); return }
        guard !busy else { return }
        voice.stopSpeaking()   // tocar na esfera interrompe a fala
        voice.requestPermissions { [weak self] ok in
            guard let self = self else { return }
            if !ok {
                self.addNote("error", "Permissão negada. Em Ajustes do iPhone > Siri, permita Microfone e Reconhecimento de Fala.")
                return
            }
            self.voice.startListening()
            if self.voice.isListening { self.setMood(.listening) }
        }
    }

    func send(_ raw: String) {
        let text = raw.trimmed
        guard !text.isEmpty else { return }
        guard !busy else { status = "Aguarde a resposta anterior…"; return }
        busy = true
        voice.stopSpeaking()
        showChat = true
        messages.append(ChatMessage(role: "user", text: text))
        setMood(.thinking)
        let hist = messages.filter { $0.role == "user" || $0.role == "assistant" }
        Task {
            do {
                let reply = try await AIClient.ask(history: hist, providerId: Prefs.provider, model: Prefs.model,
                                                   baseURL: Prefs.baseURL, apiKey: Keychain.get(account: "apikey"))
                messages.append(ChatMessage(role: "assistant", text: reply))
                Store.saveHistory(messages)
                busy = false
                if Prefs.speak && voice.speak(reply, volume: Prefs.volume) { setMood(.speaking) } else { setMood(.idle) }
            } catch {
                if let i = messages.lastIndex(where: { $0.role == "user" }) { messages.remove(at: i) }
                addNote("error", error.localizedDescription)
                busy = false
                setMood(.idle)
            }
        }
    }

    func clearHistory() {
        Store.clearHistory()
        messages.removeAll()
    }
}
