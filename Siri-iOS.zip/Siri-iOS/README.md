# Siri (iPhone, .ipa para SideStore)

App SwiftUI nativo (iOS 17+; roda no iOS 27.2). Esfera Liquid Glass, conversa com IA real, voz em português.

## Como gerar o .ipa (sem Mac)
O .ipa precisa ser compilado no macOS; o GitHub faz isso de graça:
1. Crie uma conta em github.com e um repositório **público** (público = minutos de build grátis).
2. Envie TODO o conteúdo desta pasta, inclusive a pasta oculta `.github` (pelo PC: arraste a pasta inteira em "Add file > Upload files"; se a `.github` não subir, use "Add file > Create new file", digite `.github/workflows/build-ipa.yml` e cole o conteúdo do arquivo).
3. Aba **Actions** > "Build IPA" > **Run workflow** (ou o push já dispara). Leva uns 5–10 min.
4. Quando ficar verde, vá em **Releases** (coluna direita do repositório) e baixe `Siri.ipa` pelo Safari do iPhone. Também fica em Actions > build > Artifacts (`Siri-ipa`, em .zip).

## Instalar no SideStore
Baixou o `Siri.ipa` > toque em Compartilhar > SideStore (ou, no SideStore, "+" e escolha o arquivo em Arquivos). O SideStore assina com o seu Apple ID. Conta gratuita: o app expira em 7 dias (o SideStore renova se estiver configurado) e há limite de 3 apps ativos.

## Configurar a IA (obrigatório)
Engrenagem > provedor > cole a chave > Salvar chave > "Testar conexão". Gemini tem plano gratuito. A chave fica no Chaveiro do iPhone.

## Uso
Toque na esfera: ouvir/parar. Toque durante a fala: interrompe. Teclado: modo escrever ("Pergunte à Siri"). O iOS pede permissão de microfone e reconhecimento de fala na primeira vez.

## Limites
- Sem atalho global, ativação por voz nem "iniciar com o sistema": o iOS não permite isso a apps instalados assim.
- O reconhecimento de voz do iOS pode usar os servidores da Apple.
- Sincronia da esfera com a fala usa os eventos de palavra da voz do iOS.
- Código nunca foi compilado antes (feito sem Mac): se o build falhar, abra o log da Action e me mande o erro.
